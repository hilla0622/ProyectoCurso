namespace ProyectoAsistenciaBeta1
{
    public partial class FormularioInicioSesion : Form
    {
        bool isMenuVisible = false;
        public FormularioInicioSesion()
        {
            InitializeComponent();
        }

        private void btnIniciarSesion_Click(object sender, EventArgs e)
        {
            AgregarClave form2 = new AgregarClave();

            // Mostrar el segundo formulario
            form2.Show();

            // Ocultar el formulario actual (opcional, puedes cerrarlo si prefieres)
            this.Hide();
        }
    }
}
