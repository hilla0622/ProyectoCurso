﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoAsistenciaBeta1
{
    public partial class Administrador : Form
    {
        bool isMenuVisible = false;

        public Administrador()
        {
            InitializeComponent();
        }

        public object UsuarioActual { get; private set; }

        private void AlternarVisibilidad(object sender, EventArgs e)
        {
            isMenuVisible = !isMenuVisible;
            panelMenu.Visible = isMenuVisible;
        }

        private void CerrarSesion(object sender, EventArgs e)
        {
            // Limpiar las variables de sesión
            UsuarioActual = null;

            // Redirigir a la pantalla de inicio de sesión
            FormularioInicioSesion inicioSesion = new FormularioInicioSesion();
            inicioSesion.Show();

            // Cerrar la ventana actual
            this.Close();
        }
    }
}
