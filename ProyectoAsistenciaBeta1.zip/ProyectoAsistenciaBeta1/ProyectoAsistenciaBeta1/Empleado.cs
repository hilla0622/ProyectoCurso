﻿public abstract class Empleado
{
    public string NombreUsuario { get; set; }
    public string Clave { get; set; }
    public DateTime HoraEntradaEsperada { get; set; }
    public DateTime HoraSalidaEsperada { get; set; }
    public DateTime HoraEntradaReal { get; private set; }
    public DateTime HoraSalidaReal { get; private set; }

    public Empleado(string nombreUsuario, string clave, DateTime horaEntradaEsperada, DateTime horaSalidaEsperada)
    {
        NombreUsuario = nombreUsuario;
        Clave = clave;
        HoraEntradaEsperada = horaEntradaEsperada;
        HoraSalidaEsperada = horaSalidaEsperada;
    }

    public void RegistrarEntrada()
    {
        HoraEntradaReal = DateTime.Now;
    }

    public void RegistrarSalida()
    {
        HoraSalidaReal = DateTime.Now;
    }

    public TimeSpan CalcularHorasTrabajadas()
    {
        return HoraSalidaReal - HoraEntradaReal;
    }

    public abstract void MostrarHorario();
}
