﻿public class EmpleadoVentas : Empleado
{
    public EmpleadoVentas(string nombreUsuario, string clave)
        : base(nombreUsuario, clave, new DateTime(1, 1, 1, 10, 0, 0), new DateTime(1, 1, 1, 18, 0, 0)) { }

    public override void MostrarHorario()
    {
        // Mostrado en la GUI
    }
}