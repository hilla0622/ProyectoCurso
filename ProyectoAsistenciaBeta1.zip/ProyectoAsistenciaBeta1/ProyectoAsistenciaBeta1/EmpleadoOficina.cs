﻿
    public class EmpleadoOficina : Empleado
    {
        public EmpleadoOficina(string nombreUsuario, string clave)
            : base(nombreUsuario, clave, new DateTime(1, 1, 1, 9, 0, 0), new DateTime(1, 1, 1, 17, 0, 0)) { }

        public override void MostrarHorario()
        {
            // Mostrado en la GUI
        }
    }
