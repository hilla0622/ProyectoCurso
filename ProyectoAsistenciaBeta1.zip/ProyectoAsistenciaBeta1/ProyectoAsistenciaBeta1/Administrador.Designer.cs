﻿namespace ProyectoAsistenciaBeta1
{
    partial class Administrador
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            splitContainer1 = new SplitContainer();
            panelMenu = new Panel();
            groupBox1 = new GroupBox();
            button5 = new Button();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            tabPage2 = new TabPage();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).BeginInit();
            splitContainer1.Panel1.SuspendLayout();
            splitContainer1.Panel2.SuspendLayout();
            splitContainer1.SuspendLayout();
            panelMenu.SuspendLayout();
            groupBox1.SuspendLayout();
            tabControl1.SuspendLayout();
            SuspendLayout();
            // 
            // splitContainer1
            // 
            splitContainer1.Dock = DockStyle.Fill;
            splitContainer1.Location = new Point(0, 0);
            splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            splitContainer1.Panel1.BackgroundImage = Properties.Resources.fondo_abstracto_borroso_58702_1514;
            splitContainer1.Panel1.Controls.Add(panelMenu);
            splitContainer1.Panel1.Controls.Add(button1);
            // 
            // splitContainer1.Panel2
            // 
            splitContainer1.Panel2.Controls.Add(tabControl1);
            splitContainer1.Size = new Size(935, 598);
            splitContainer1.SplitterDistance = 210;
            splitContainer1.TabIndex = 0;
            // 
            // panelMenu
            // 
            panelMenu.BackgroundImage = Properties.Resources.fondo_abstracto_borroso_58702_1514;
            panelMenu.Controls.Add(groupBox1);
            panelMenu.Dock = DockStyle.Top;
            panelMenu.Location = new Point(0, 29);
            panelMenu.Name = "panelMenu";
            panelMenu.Size = new Size(210, 536);
            panelMenu.TabIndex = 1;
            panelMenu.Visible = false;
            // 
            // groupBox1
            // 
            groupBox1.BackgroundImage = Properties.Resources.fondo_abstracto_borroso_58702_1514;
            groupBox1.Controls.Add(button5);
            groupBox1.Controls.Add(button4);
            groupBox1.Controls.Add(button3);
            groupBox1.Controls.Add(button2);
            groupBox1.Dock = DockStyle.Top;
            groupBox1.Font = new Font("Times New Roman", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(0, 0);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(210, 200);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Menu de Opciones";
            // 
            // button5
            // 
            button5.Dock = DockStyle.Top;
            button5.Font = new Font("Times New Roman", 10.2F);
            button5.Location = new Point(3, 108);
            button5.Name = "button5";
            button5.RightToLeft = RightToLeft.No;
            button5.Size = new Size(204, 29);
            button5.TabIndex = 3;
            button5.Text = "Cerrar Sesión";
            button5.UseVisualStyleBackColor = true;
            button5.Click += CerrarSesion;
            // 
            // button4
            // 
            button4.Dock = DockStyle.Top;
            button4.Font = new Font("Times New Roman", 10.2F);
            button4.Location = new Point(3, 79);
            button4.Name = "button4";
            button4.Size = new Size(204, 29);
            button4.TabIndex = 2;
            button4.Text = "Bonos";
            button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.Dock = DockStyle.Top;
            button3.Font = new Font("Times New Roman", 10.2F);
            button3.Location = new Point(3, 50);
            button3.Name = "button3";
            button3.Size = new Size(204, 29);
            button3.TabIndex = 1;
            button3.Text = "Horarios";
            button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Dock = DockStyle.Top;
            button2.Font = new Font("Times New Roman", 10.2F);
            button2.Location = new Point(3, 21);
            button2.Name = "button2";
            button2.Size = new Size(204, 29);
            button2.TabIndex = 0;
            button2.Text = "Registrar Empleados";
            button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.Dock = DockStyle.Top;
            button1.Font = new Font("Times New Roman", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(0, 0);
            button1.Name = "button1";
            button1.Size = new Size(210, 29);
            button1.TabIndex = 0;
            button1.Text = "Administrar";
            button1.UseVisualStyleBackColor = true;
            button1.Click += AlternarVisibilidad;
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Dock = DockStyle.Fill;
            tabControl1.Location = new Point(0, 0);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(721, 598);
            tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            tabPage1.BackgroundImage = Properties.Resources.fondo_abstracto_borroso_58702_1514;
            tabPage1.Font = new Font("Times New Roman", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tabPage1.Location = new Point(4, 29);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(713, 565);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Registrar nuevo empleado";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            tabPage2.BackgroundImage = Properties.Resources.fondo_abstracto_borroso_58702_1514;
            tabPage2.Font = new Font("Times New Roman", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tabPage2.Location = new Point(4, 29);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(713, 565);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Registro de Empleados";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // Administrador
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.fondo_abstracto_borroso_58702_1514;
            ClientSize = new Size(935, 598);
            Controls.Add(splitContainer1);
            Name = "Administrador";
            Text = "Administrador";
            splitContainer1.Panel1.ResumeLayout(false);
            splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)splitContainer1).EndInit();
            splitContainer1.ResumeLayout(false);
            panelMenu.ResumeLayout(false);
            groupBox1.ResumeLayout(false);
            tabControl1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private SplitContainer splitContainer1;
        private Panel panelMenu;
        private Button button1;
        private GroupBox groupBox1;
        private Button button4;
        private Button button3;
        private Button button2;
        private Button button5;
        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
    }
}