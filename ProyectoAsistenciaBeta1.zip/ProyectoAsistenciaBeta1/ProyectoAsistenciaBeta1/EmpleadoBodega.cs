﻿public class EmpleadoBodega : Empleado
{
    public EmpleadoBodega(string nombreUsuario, string clave)
        : base(nombreUsuario, clave, new DateTime(1, 1, 1, 7, 0, 0), new DateTime(1, 1, 1, 15, 0, 0)) { }

    public override void MostrarHorario()
    {
        // Mostrado en la GUI
    }
}
