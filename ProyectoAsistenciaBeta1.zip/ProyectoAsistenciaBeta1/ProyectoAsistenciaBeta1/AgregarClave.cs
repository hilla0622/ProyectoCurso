﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoAsistenciaBeta1
{
    public partial class AgregarClave : Form
    {
        public AgregarClave()
        {
            InitializeComponent();
        }

        private void Ingresar(object sender, EventArgs e)
        {
            //Valida cion de la clave ingresada
            if(txtClave.Text == "admin")
            {
                Administrador administrador = new Administrador();
                administrador.Show();
                this.Hide();
            }
            else if(txtClave.Text == "emple")
            {
                FormularioEmpleado formularioEmpleado = new FormularioEmpleado();
                formularioEmpleado.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Clave Incorrecta, por favor intente de nuevo.");
            }
        }
    }
}
